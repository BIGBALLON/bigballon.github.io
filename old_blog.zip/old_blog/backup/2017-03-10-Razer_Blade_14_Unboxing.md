---
layout: post
title: Razer Blade 14 Unboxing
date: 2017-03-10 23:48
---

### 0X000001 写在前面的滑稽

说起来也不容易，这台电脑从购买到开箱花了半个月的时间，233XD。
没有Visa卡，Seven又不能付款，找了个学长帮我付款，而后又卡在了海关，前后找学长找了好多次，最后终于是材料齐全通关了。超过1000美刀的东西一定会被扣下来233，有无线装置的东西也要被扣下来，233XD。

![][1]

### 0X000002 犹如吸大麻般的开箱

记得晚上11点和老师商量了meeting时间，然后先老师一步离开lab，会宿舍开箱，233XD。


![][2]

话说寄回来的通关材料好几十页啊，233XD。

![][3]

兴奋中

![][4]

黑盒好评

![][5]

![][6]


### 0X000003 爆炸的是chroma幻彩背光灯

拿到手才知道原来razer的背光灯如此强悍，全按键，RGB 0～255 可以随便调节。  
更厉害的是chroma幻彩应用，，，舍友拿我电脑开顶配测守望先锋，键盘居然会随着游戏角色的改变而变换颜色，包括人物攻击，人物死亡，全部会检测，23333XD，感觉帅炸了。


![][7]

![][8]

![][9]

### 0X000004 配置一览

![][10]

![][11]

![][12]

![][13]

![][14]


另外还送了这些玩意：

> Razer Kraken Pro 2015 (綠色) 價值 NT$2,990.  

> Razer DeathAdder Chroma 價值 NT$2,290.

> 獲得全版 FL Studio 12 Producer Edition (價值 US$199). 

另外吐槽一下国内官网居然现在还在卖GT970的卡，真心是看不下去  
而且还足足比我的贵了2000RMB,更重要的是我还有赠品，XD  
好东西要想进国内市场还真是难，而且价格还是虚高，，真是可惜。

### 0X000005 终于有一款活力十足的利器了

---


![nice][15]


  [1]: http://7xi3e9.com1.z0.glb.clouddn.com/r1.jpg
  [2]: http://7xi3e9.com1.z0.glb.clouddn.com/r2.jpg
  [3]: http://7xi3e9.com1.z0.glb.clouddn.com/r4.jpg
  [4]: http://7xi3e9.com1.z0.glb.clouddn.com/r5.jpg
  [5]: http://7xi3e9.com1.z0.glb.clouddn.com/r6.jpg
  [6]: http://7xi3e9.com1.z0.glb.clouddn.com/r7.jpg
  [7]: http://7xi3e9.com1.z0.glb.clouddn.com/r9.jpg
  [8]: http://7xi3e9.com1.z0.glb.clouddn.com/20170308135028.png
  [9]: http://7xi3e9.com1.z0.glb.clouddn.com/razer01.png
  [10]: http://7xi3e9.com1.z0.glb.clouddn.com/20170308134716.jpg
  [11]: http://7xi3e9.com1.z0.glb.clouddn.com/20170308134725.png
  [12]: http://7xi3e9.com1.z0.glb.clouddn.com/20170308134737.png
  [13]: http://7xi3e9.com1.z0.glb.clouddn.com/20170308134732.png
  [14]: http://7xi3e9.com1.z0.glb.clouddn.com/20170308134742.jpg
  [15]: http://7xi3e9.com1.z0.glb.clouddn.com/webwxgetmsgimg.jpg