---
layout: post
title: Diary
date: 2016-07-01 21:48
---

#### 07-13 Monday

昨天结束了DL 的[final project][1]，哈哈，视频传到bilibili去了，哈哈哈。。。  
额。。。研一似乎好像结束了，，捂脸，，好像没有，呵呵。  
“被迫” 参加百度和西交举办的比赛？？？？     
强烈鄙视一下baidu，，图片都不处理下，还直接放了url，，真的是穷吗？    
曾经的百度去哪里了？  现在的baidu，真的是XXX  
还是为了搞比赛而搞比赛啊？ 还是百度的程序员烂到这种程度？ 好，当我没说。  
恩，初步用了一下VGG19.  
图片预处理这部分在这个比赛中看起来很重要，另外就是架构。
看起来很容易overfitting？现在还不确定。  



#### 06-26 Monday

期末考试结束，[AI][2]满分，其他未知。  
要开始进入theta的计划，以及继续学习DL和RL的知识，以及象棋的事情。

#### 06-15 Thursday

期末考试ING


#### 05-08 sunday

澎湖 TCGA “三日游”， 图就不上了

#### 04-22 saturday

最近好累啊,,23333... 作业好多..2333


#### 03-23 Thursday

好久没写日记了，，突然想起来就随便写点吧。  
这一周都在train NIN，前后加起来耗时估计有48小时。  
下一步如果有时间的话再来整理blog好了，把bigdata的hw1做完了，最近作业多得有点爆炸。  

![nin][3]

#### 02-28 Tuesday

额。。不小心把小皮卡丘丢掉了。。2333 晕

![p][4]

#### 02-17 Friday

開學有幾天了，慢慢開始進入狀態。這學期任務比較艱巨。不過沒什麼。

![][5]
![][6]
![][7]

接下來是向DL進發了！

#### 02-12 Saturday

看了下表，现在时间，晚上11点17分。我躺在床上，打开笔记本，开着电视....  


不想打扰太多人，一个人乘车来到厦门，打的去预定好的如家，路上出了一点小插曲，嘉禾路有很多个如家，司机把我拉错了地方..   
明早8点多的飞机，预定送机车的时候也遇到点小麻烦，没有大陆的手机号，也没办法订车，最后用了XL的手机号.  

弄好后出门寻觅食物，街上异常地凄凉，也许是都在装修的缘故，好多店都没有顾客，弄得我都不好意思进去.  
回来的路上才想起，今天是元宵节，也许大家都在家里聚会吧.

好久没有住过宾馆了，又想起了以前出去比赛辗转于如家，7天等酒店时光，如今早已没有了比赛的感觉..

微信上到处都在发元宵节的红包，我无心去抢..

回看大学四年的时光，做过一些啥事，做过一些疯狂的事，做过一些对的事，也做过一些自豪的事..  
大巴上也是无聊，没有手机号没有网络的我，打开手机里唯一有音乐的视频，毕业前夕给班级做的留念视频..  

研一上学期的表现给自己打80分，挺累也挺辛苦不过自己可以做得更好..  
身边每一位同学都是高手，有压力也有动力..  
事情很多，时间很紧，课业很重，如何合理安排显得更加重要..

祝大家元宵节快乐吧，新学期，新气象，更要，加油...


![huhu][8]

另外，陪伴我4年半的笔记本，也是时候换了，感谢你的陪伴，我打算台MSI了... 





#### 02-04 Saturday

新的一年，新的开始！  
加油！

#### 12-30 Friday

额，12月即将结束。。  
今天了却了两桩大事，NP DEMO 和 seminar 第二次。    
稍微休息一下，还得继续。。。。。。。。  
还有一个月，就可以回家了。  
祝大家元旦快乐吧。  
我元旦应该还要lu代码！  2333333333333333333333333333333333...        

![][9]

tyyxzm

#### 12-06 Tuesday


刚刚和老爸通过了电话，老爸像往常一样给我敲警钟，而这次我却非常理智地接受以及思考。  
从小学一直到大学，都是在尖子班，而进入尖子班中我却总是因为畏难情绪而迷失自己。  
其实那都不是真实的自己。我可以做得更好。

回头想想，没什么好怕的啊？  
突然想起来一句非常有道理的名言，很朴实但是很能说明问题啊。  

畏难说好听点，就是要求高，要求高才有难。放低要求，腆脸先启动起来再说。  
小时候没学过么？天下事有难易乎，为之，则难者亦易矣，不为，则易者亦难矣。  
把大的难的任务分解为若干小任务，更容易实现。就算没完全实现，也能部分实现。  
小时候没学过么？不积跬步无以至千里，不积小流无以成江海。  
自信，其实是一种掌握感，是一点一点建立起来的。反复试错，反复练习，熟练了你就自信了。  
小时候没学过么？失败是成功之母。（其实是重复是成功之母。）  

> 天下事有难易乎，为之，则难者亦易矣，不为，则易者亦难矣。  

努力去做就好了，哪里来那么多难不难。  
恩，加油！！


#### 11-28 Monday

这个月经历了很多事，具体的已经记不太清楚了。  
原先要写的知乎专栏，考虑到这是我们LAB的知识产权，可能不会放在知乎上了，也可能会以其他方式来写？I'm not sure.  
到了其中课业变得更加艰难，那只有继续前行。  
上周参加了TAAI，也算是杰哥带我一路carry。我们lab还是强啊。  
调整一下，马上就是下个月了，blog这种东西，都没什么想法和动力更新了，找机会再更新吧！  

放几张图片意思一下吧。。  

![][10]

![][11]

![][12]

![][13]

![][14]

![][15]

![][16]

![][17]



#### 11-06 Sunday

- 周一:    TCG hw3从晚上8点写到凌晨4点半。   
- 周二:    写TCG到凌晨两点·交了TCG hw3，又下来TCG project3 和 hw4. 晚上和学长讨论新的攻勢，然后和ting demo project2，去年最高好像是97%，貌似我今年创造了新的记录?  
- 周三:    晚上，和依林约了11点宿舍讨论，结果在Lab写code忘记了，赶回读书讨论到12点半，继续写TCG 的artificial，忘记几点睡。  
- 周四:    开始准备写NP的project…结果继续写了TCG的artificial以及Cchess分析开局的盘面。目测3点睡?不清楚  
- 周五:    写了一整天NP,晚上继续seminar，一直有bug，没调出来，，pipe来pipe去快晕了。 。 凌晨4点半，抓狂睡觉。 。 。  
- 周六:    一整天NP,从下午1点写到晚上12点，离开Lab，还是有bug，回宿舍继续写，开始怀疑人生，bsd的ls和cat一直出问题，在凌晨5点，感觉要放弃这个世界的时候，突然找到bug，写完了，看到PASS眼淚都快掉下來。[流泪]，天快亮了，，上床睡觉。  
- 周天:   睡到今天早上，不，今天中午11点，飞往Lab，继续NP的coding，调到5点10分，提交了project。 。 。 。  

然后晚上和Lab的学长们一起去吃羊肉炉，一起聊天很开心！！！！ 呜呜  

总体来说，这周主要花在可以上，Lab上的事情没有抽出太多时间。
然后NP马上会有下一个project以及现在还有TCG的hw4和project3。明天目测还会有DM的hw。 。

然后这周很充实，，几乎全天脑子都在转，希望能挤出更多的时间在我Lab的事情上以及25号的TAAI会议。

之前還擔心我大四胖了10多斤會不會發福，現在看來我的擔心多餘了，我還是那麼瘦，開心(*^ω^*)


#### 10-31 Monday

最近hw真的是有点多，而且不简单。。。
正在努力写hw和project，感觉整个人被掏空了。。今晚一定要做完TCG的hw3，明天做NP。。

#### 10-25 Tuesday

最近幾天比較多事，Cchess的CNN還不知道怎麼搞。  
額。週天去看了your name確實不錯，好評。  
盡快把那兩篇paper看完看看有沒有一些啟示，  
今天搞笑的事情是在上TCG的時候，有講到NagaScout的時候，我們追問了老師一整堂課，哈哈  。  
沒時間寫blog吖，2333.

#### 10-21 Friday

最近準備入坑DL了。希望能夠把CNN用在chinese chess上。  
下個月有TAAI會議！！！！應該可以去參加一次，沒準還能參賽，期待中。  
一大波新東西要學，一大波hw要做，一大波paper在讀。  
然而卻很開心，，另外今天感謝筱茜給我講CNN。thx！！！    



#### 10-20 Thursday


NP的project下來的時候，果然感到了一陣壓力，不過也做好了準備。    
果然是傳說中很heavy的course。    
結果今天開始優化code，，，沒想到效果這麼好，，看來framework裡面的bit運算確實寫得很渣。。。    
優化之後 moves/sec 從 40000 -> 80000.    
有嘗試新的features，不過可能並不會比先前的好，在training幾天，demo之前再看效果吧XD。  

生活還要繼續，，加油咯！！   
等稍微有點時間，看看blog開一點新坑。。2584鐵定是要write了。TCG也鐵定會write，  
置於DM可能？？不知道，另外會關注CNN deep learning的東西，沒準會寫一些ML的總結呢？  
哦，還有看盤面，找feature，這週週末把近期的比賽都看完吧！  


#### 10-18 Tuesday

好久沒有寫日記，這些天過得很充實。    
lab的生活很好。     
最近已經開始寫2584的AI了。目前進度使用了TD learning 來training   
目前有用過的features有 line (4-tuple) 和 box ax(6 tuple).   
我還加了610 limited，這個確實很有效，還有感謝CL那天幫我debug到凌晨2點，thx!  
另外膜拜一下lab的學長學姐們發的那兩篇paper，果然是TD learning在2048-like game裡面的精髓！    

![1line1box1ax][18]

目前來看已經比較理想了。  

後續還會加上alpha-beta pruning！！

然後是這週一大波hw和project又來了。  
另外一個值得挑戰的地方是明年需要發的paper，對我來說無疑是一個很大的挑戰。   
所以後續會focus在deep learning 和 CNN 上面多一點。   

也希望我們的chimo可以越來越強，畢竟我是chinese chess 組的！！XD  

so, 要開的坑有 

- stockfish  
- CNN   
- Deep Learning
- 最好RL的東西也看完
- 以及TCG的東西。。。。



#### 10-02 Tuesday

在lab待了半個月了。  
慢慢適應了這裡的生活。  
昨天把editor寫完。。happy。the first task of CGI Lab.  

今天陸聯會的小聚，還算是挺棒的。大家都加油！！！  

Lab的每一個人都好強。我也要繼續努力了。。。
我會記住老師的話，just fight！！


![][19]

每年都很開心收到實驗室同學的教師節卡片 (包括兩顆泡芙 :>).   
其實我認為, 我的學生都是藍波萬, 即使進來的時候不是, 出去的時候也一定是, 或一定要是.  

I will try my best!



#### 09-27 Tuesday

今天，，颱風假，，明天，，颱風假。。  
最近不是很有時間更新我的blog，過一段時間再好好寫點總結吧。  
近期任務：   

> 1. 課業，認真完成hw和project 
> 2. editor-->chess  
> 3. stockfish source code，儘快找時間看吧



#### 09-12 Monday

今天第一天上課，資料勘探「數據挖掘」————————————————  
去了交大圖書館借了好多本書，，，，，，「逼格相當高，爆本科學校幾百條街」————————————   
——————————————   

![][20]

![][21]



#### 09-11 Sunday

下午整理下本學期要上的課程   
晚上一起出去吃了一個「大呼過癮」小火鍋 cost 160   
回來重裝了系統，用的是學校的全套正版軟體，感覺相當不錯！

![][22]

![][23]

![][24]

明天第一天上課，UP！



#### 09-10 Saturday

早上7點40起床，去體檢————————————————  
之後去了二餐的一樓吃了個麥香漢堡+薯餅+奶茶。「這裡的奶茶果然甜，不是很喜歡喝太甜的東西」  
中午回來睡了一覺，起來和子翔、依林、大釗去打籃球了。  
晚飯在三樓，然而今天不太好吃。。。23333，遇到一大波人在吃餃子，不知道是什麼活動。    
晚上三人搭車去了全lian，花了600塊，買了一大堆東東，，哈哈哈哈哈哈。。。23333  
明天休息一天，，，，準備開始上課了，23333。。。
記得週三去取郵政的儲蓄卡。  
21號去醫院取報告單，順便去辦多次通行證。

![][25]

![][26]





#### 09-09 Friday

早上7點20起床，洗漱，下樓，乘坐昨晚叫好的出租車「叫的7點40，7點36就來了，可以」前往臺大醫院新竹分院————去幹嗎，，，體檢啊。

糞便，抽血，X光，皮膚。花了1700+塊

![][27]

回來，吃了中飯，35塊，超便宜，依林20塊，文澤45塊，子翔55塊。二餐的三樓真心實惠。
菜多，符合大陸口味，更符合大陸南方人的口味，青菜種類多，連四季豆都有。肉種類也多，很不錯，飯免費，湯免費。  

下午，，繼續新生訓練，講了好多，挺好的。   

![][28]

然後，，，去了郵局，，，交了學費，，，哈哈哈，，40000多台幣嘩嘩嘩沒了。
然後班了個郵政的存折。。。


晚上，花了50塊錢吃飯，吃了「八方雲集」 5個水餃+5個鍋貼。還不錯。  

明天。。。。校內體檢，，又要花700了。哈哈哈哈哈。。。。


#### 09-08 Thursday  

剛來這幾天估計會特別忙，，特別多事要處理。  

![][29]

中午在二餐吃了一份鸡排饭，70塊錢，，4大塊雞排，都沒吃完，分量相當足，額。。這個還是相當划算的。 另外據說三樓更便宜，50塊錢就能吃得不錯。下次去試試。。  

另外，，，中午取錢2333.試了兩個ATM取不出來嚇了一跳以為鎖卡了。  
貌似每天也只能額定取1萬RMB之內吧。  

飯後又穿過清華去了趟遠傳補資料。。2333結果大通證早上交上去了，我的天呐。難道又要去一次，，還好可以明天領回來之後拍照片發過去。。。。  

回來路上刻了個印章，明天看看能不能有時間去交個學費，順便開一個戶頭。  
在一個小店花了390買到了洗發水，沐浴露，指甲刀，剪刀，日常用的透明膠和雙面膠，這個還算相當實惠的。  
早上照片少一張還得找個時間去國際處補一下。。  
233 明天一早要去做入境體檢，，，事好多。。。



#### 07-21 Thursday  

> Section 3.1   
DONE  2016.07.21  PROB Humble Numbers [ANALYSIS]  DP   
DONE  2016.07.21  PROB Contact [ANALYSIS]  map+vetor ? trie ? ac auto?  
DONE  2016.07.21  PROB Stamps [ANALYSIS]   DP 

> Section 3.2   
DONE  2016.07.21  PROB Factorials [ANALYSIS]    水题  

跑了20000步

#### 07-20 Wednesday

> Section 3.1    
DONE  2016.07.20  PROB Agri-Net [ANALYSIS]  最小生成树  
DONE  2016.07.20  PROB Score Inflation [ANALYSIS]  完全背包  

下午泡了个温泉，，，清爽。


#### 07-19 Tuesday

> Section 2.2  
DONE  2016.07.17  PROB Party Lamps [ANALYSIS]  dfs  

> Section 2.3  
DONE  2016.07.17  PROB The Longest Prefix [ANALYSIS] DP   
DONE  2016.07.17  PROB Cow Pedigrees [ANALYSIS]  DP  
DONE  2016.07.18  PROB Zero Sum [ANALYSIS]  dfs  
DONE  2016.07.18  PROB Money Systems [ANALYSIS]  DP  完全背包  
DONE  2016.07.18  PROB Controlling Companies [ANALYSIS]  dfs  

> Section 2.4    
DONE  2016.07.19  PROB The Tamworth Two [ANALYSIS]  模拟  
DONE  2016.07.19  PROB Overfencing [ANALYSIS]  从两个出口分别bfs  
DONE  2016.07.19  PROB Cow Tours [ANALYSIS]  floyd + 并查集  
DONE  2016.07.19  PROB Bessie Come Home [ANALYSIS]  最短路   
DONE  2016.07.18  PROB Fractions to Decimals [ANALYSIS]  余数..模拟...   

MDZZ....

#### 07-13 Wednesday

> seciton 2.2  
DONE  2016.07.13  PROB Preface Numbering [ANALYSIS]  罗马数字挺好玩的， 模拟！   
DONE  2016.07.13  PROB Subset Sums [ANALYSIS]  0-1背包 DP   
DONE  2016.07.13  PROB Runaround Numbers [ANALYSIS] 这题智障。。。    

> seciton 2.1 达成  
DONE  2016.07.12  PROB The Castle [ANALYSIS]  
说下这题，首先存储地图信息，然后用floodfill染色，颜色相同的区域成为一个房间。  
然后是拆墙，从左下开始遍历到右上。颜色不同的两个房间之间，说明必定有墙。


#### 07-12 Tuesday

被吐槽不好好刷题了，玩了两天pokemon go，回了趟老家，最近有点浮躁，烦啊，我只想安安心心刷题。  

> seciton 2.1  
DONE  2016.07.12  PROB Sorting A Three-Valued Sequence [ANALYSIS]  
DONE  2016.07.12  PROB Healthy Holsteins [ANALYSIS]  
DONE  2016.07.12  PROB Hamming Codes [ANALYSIS]  

> 还是卡在这题，，2333.  
VIEWED  2016.07.07  PROB The Castle

#### 07-09 Saturday

Pickt people pick Peter Pan peanut butter.  
Peter Pan peanut butter is the peanut butter picky people pick.

A big black bug bit a big black bear and made the big  
black bear bleed blood.


#### 07-08 Friday

今天算是彻底颓废了一天，，，好不容易入坑pokemon Go，结果还赶上锁区了。  
国服上线讲道理还有一段时间。。  
还是好好刷题吧。。

今天开始 chapter 2，第一题，NOI，不会，第二题，水题。。，第三题NOI。。。  
明天再想吧。。。。。。。。  

#### 07-07 Thursday

> Section 1.2 达成。。。  
Palindromic Squares 和 Dual Palindromes，这两题没差啊。  
Transformations，模拟  
Milking Cows ，贪心  
Name That Number， 模拟，枚举


> Section 1.3 达成。。。  
....

> Section 1.4 达成。。。  
....

> Section 1.5 达成。。。  
chapter 1 达成。。。。。  
orz2333。。还能不能愉快的玩耍了，，我只想安心搞学术。  


#### 07-05 Tuesday 

昨天啥都没干就重装了个系统 不过。感觉神清气爽。。。。。2333   
打算花一个月的时间刷通USACO。  

> Section 1.1 达成。。。  
broken necklace卡了很久...
233我忘记考虑字符'w'的特殊情况。  

> Section 1.2 ing  
....


  [1]: https://youtu.be/96WcshnH6yA
  [2]: git@github.com:BIGBALLON/NCTU_AI.git
  [3]: http://7xi3e9.com1.z0.glb.clouddn.com/17453286_425471971178355_1280843406_o.png
  [4]: http://7xi3e9.com1.z0.glb.clouddn.com/1703528_1126646787_n.png
  [5]: http://7xi3e9.com1.z0.glb.clouddn.com/1896940093.jpg
  [6]: http://7xi3e9.com1.z0.glb.clouddn.com/1161837298.jpg
  [7]: http://7xi3e9.com1.z0.glb.clouddn.com/1181906956.jpg
  [8]: http://7xi3e9.com1.z0.glb.clouddn.com/45_meitu_1.jpg
  [9]: http://7xi3e9.com1.z0.glb.clouddn.com/0.jpg
  [10]: http://7xi3e9.com1.z0.glb.clouddn.com/ti1.jpg
  [11]: http://7xi3e9.com1.z0.glb.clouddn.com/ti2.jpg
  [12]: http://7xi3e9.com1.z0.glb.clouddn.com/ti3.jpg
  [13]: http://7xi3e9.com1.z0.glb.clouddn.com/ti4.jpg
  [14]: http://7xi3e9.com1.z0.glb.clouddn.com/ti5.jpg
  [15]: http://7xi3e9.com1.z0.glb.clouddn.com/ti6.jpg
  [16]: http://7xi3e9.com1.z0.glb.clouddn.com/ti7.jpg
  [17]: http://7xi3e9.com1.z0.glb.clouddn.com/ti8.jpg
  [18]: http://7xi3e9.com1.z0.glb.clouddn.com/1l1ax1box.png
  [19]: http://7xi3e9.com1.z0.glb.clouddn.com/SKSK.PNG
  [20]: http://7xi3e9.com1.z0.glb.clouddn.com/29046958239699106.jpg
  [21]: http://7xi3e9.com1.z0.glb.clouddn.com/167103069215840681.jpg
  [22]: http://7xi3e9.com1.z0.glb.clouddn.com/8C.tmp.png
  [23]: http://7xi3e9.com1.z0.glb.clouddn.com/filehelper_1473609958055_98.png
  [24]: http://7xi3e9.com1.z0.glb.clouddn.com/filehelper_1473609965104_55.png
  [25]: http://7xi3e9.com1.z0.glb.clouddn.com/Y1kb.png
  [26]: http://7xi3e9.com1.z0.glb.clouddn.com/Y1kc.png
  [27]: http://7xi3e9.com1.z0.glb.clouddn.com/33434343.png
  [28]: http://7xi3e9.com1.z0.glb.clouddn.com/2016090s9121555.png
  [29]: http://7xi3e9.com1.z0.glb.clouddn.com/s0160908190654.png