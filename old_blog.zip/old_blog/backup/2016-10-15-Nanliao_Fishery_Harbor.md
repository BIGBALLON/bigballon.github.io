---
layout: post
title: Naoliao Fishery Harbor
categories: [pokemon]
tags: [pokemon]
---

Yesterday, I completed my first seminar report, and today I decide to go to Nanliao to catch Pokemon with my roommate! 

![][1]

A journey from the library

![][2]

Arrived in Nanliao

![][3]

People mountain people sea

![][4]

Me?

![][5]

Because someone's misleading, a lot of people rushed here.

![][6]

Stinky tofu

![][7]

rainbow Sorbet

![][8]

Cool 

![][9]

Just for fun!

![][10]

A pretty girl

![][11]

A lot of cars

![][12]

Sunset

![][13]

![][14]

![][15]



![][16]

![][17]

Before we came back, we met lapras！！amazing！！！！wow！  
Everyone was very happy!

![][18]

![][19]

Today's gains!!

![][20]

A good day!!!



  [1]: http://7xi3e9.com1.z0.glb.clouddn.com/nl000.PNG
  [2]: http://7xi3e9.com1.z0.glb.clouddn.com/nl001.PNG
  [3]: http://7xi3e9.com1.z0.glb.clouddn.com/nl002.PNG
  [4]: http://7xi3e9.com1.z0.glb.clouddn.com/nl003.PNG
  [5]: http://7xi3e9.com1.z0.glb.clouddn.com/nl004.PNG
  [6]: http://7xi3e9.com1.z0.glb.clouddn.com/nl005.PNG
  [7]: http://7xi3e9.com1.z0.glb.clouddn.com/nl006.PNG
  [8]: http://7xi3e9.com1.z0.glb.clouddn.com/nl007.PNG
  [9]: http://7xi3e9.com1.z0.glb.clouddn.com/nl008.PNG
  [10]: http://7xi3e9.com1.z0.glb.clouddn.com/nl009.PNG
  [11]: http://7xi3e9.com1.z0.glb.clouddn.com/nl010.PNG
  [12]: http://7xi3e9.com1.z0.glb.clouddn.com/nl011.PNG
  [13]: http://7xi3e9.com1.z0.glb.clouddn.com/nl012.PNG
  [14]: http://7xi3e9.com1.z0.glb.clouddn.com/nl013.PNG
  [15]: http://7xi3e9.com1.z0.glb.clouddn.com/nl014.PNG
  [16]: http://7xi3e9.com1.z0.glb.clouddn.com/nl015.PNG
  [17]: http://7xi3e9.com1.z0.glb.clouddn.com/nl016.PNG
  [18]: http://7xi3e9.com1.z0.glb.clouddn.com/nl017.PNG
  [19]: http://7xi3e9.com1.z0.glb.clouddn.com/nl019.PNG
  [20]: http://7xi3e9.com1.z0.glb.clouddn.com/nl020.PNG