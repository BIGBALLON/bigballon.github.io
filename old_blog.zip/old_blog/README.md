BIGBALLON: 
======

This is my personal blog.  
Always think positively,always improve your potential.

Please feel free to contact me for any questions, thank you!