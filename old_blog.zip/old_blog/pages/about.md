---
layout: post
title: About
date: 2017-08-21 22:48
---

Hi, man! Thanks for reading my personal website.

My name is Wei Li. I am a pre acmer, pre ppter.

Now, I am a graduate student at [Computer Games and Intelligence(CGI) Lab][1] of NCTU([National Chiao Tung University][2]).     
My main research area is Deep Learning , Reinforcement Learning and [computer game AI][3]( Go, Hex, 2048, Chess, Chinese Chess, Mahjong etc. ).   
If you have any question, please feel free to contact me, thank you!   


## Experiences

$2012 -2016 \; Chang'an \;University.  \;\;$      

> $Software \;Engineering $   

$2016- 20xx\;National \;Chiao-Tung \;University. \;\;$    

> $Computer \;Science \;$    
$@Institute \;of \;Computer \;Science \;and \;Engineering(IOC)$    
$@Computer \;Games \;and \;Intelligence (CGI) \;Lab$

## Contact Me

> 「Email address」: fm.bigballon$@$gmail.com 

[「Github」][10] · [「Zhihu」][11] · [「Facebook」][12]


<div id="disqus_thread"></div>
<script>

(function() { // DON'T EDIT BELOW THIS LINE
    var d = document, s = d.createElement('script');
    s.src = '//bigballon.disqus.com/embed.js';
    s.setAttribute('data-timestamp', +new Date());
    (d.head || d.body).appendChild(s);
})();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>



  [1]: http://www.aigames.nctu.edu.tw/
  [2]: http://www.nctu.edu.tw/
  [3]: http://aigames.nctu.edu.tw/~icwu/honors.html
  [4]: https://github.com/BIGBALLON/Fib2584_AI
  [5]: http://www.cnblogs.com/AOQNRMGYXLMV/
  [6]: http://jcf94.com/about/
  [7]: http://flowsnow.net/
  [8]: https://virusdefender.net/
  [9]: http://www.cnblogs.com/wuyuewoniu/
  [10]: https://github.com/bigballon
  [11]: https://www.zhihu.com/people/BIGBALLON
  [12]: https://www.facebook.com/fm.bigballon