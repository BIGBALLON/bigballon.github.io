---
layout: post
title: bg'S recycle bin
date: 2016-12-01 21:48
---

这是我的回收站，回收一些有的没的「videos」「ppts」or「slides」。balabalabalabla

  

> 研究生阶段：「短期（1年）内不提供下载，thanks」

---

- Design and Development of Online Judge System
- PM2.5 Sensor Reliability
- Dual Lambda Search and Shogi Endgames
- Dancing Links and Exact Cover
- Giraffe Using Deep Reinforcement Learning to Play Chess
- Short-Term Quantitative Precipitation Forecasting
- Reinforcement Learning with Unsupervised Auxiliary Tasks
- Solving physical problems with Deep Reinforcement Learning

  

> 大学以及高中时代：

---

- [2016级软件二班毕业留念][1]「[ppt][2]」
- [经验交流会PPT][3]
- [毕业设计论文][4]
- [毕业答辩扣脚PPT][5]
- [How to write a crawler][6]
- [浅谈Inode][7]
- [Where did innovation go AV画质，土豆差评][8] 「[ppt][9]」
- [Sequence 01][10]
- [Pollard_rho算法详解][11]
- [从PL0到Flex——编译原理扣脚笔记][12]
- [this is ACM][13]
- [冒险岛 奇袭者 连锁技能展示][14]
- [D_3-废话系列][15]
- [D_2-废话系列][16]
- [D_1-废话系列][17]
- [Ubuntu 14.04 Virtual Judge的搭建][18]
- [信息科协答辩][19] 「[ppt][20]」
- [病毒扯蛋系列-纪念被我搞坏的那台电脑][21]
- [科协微电影——梦想创意][22]
- [班服设计大赛][23]
- [班级风采大赛决赛][24]「[ppt][25]」
- [高考，来吧][26]
- [大学三部曲《探》][27]「[ppt][28]」
- [我只是个初心者][29] 「[ppt][30]」


  [1]: http://www.tudou.com/programs/view/KL1AG7ug798
  [2]: http://pan.baidu.com/s/1nuGfgQt
  [3]: http://pan.baidu.com/s/1jIpxcHo
  [4]: http://pan.baidu.com/s/1qYbDGNM
  [5]: http://pan.baidu.com/s/1jIQAOEa
  [6]: http://pan.baidu.com/s/1eSJXu5W
  [7]: http://pan.baidu.com/s/1kVNkWgJ
  [8]: http://www.tudou.com/programs/view/Y_vUn63Y65U/
  [9]: http://pan.baidu.com/s/1hr8NKiw
  [10]: http://www.tudou.com/programs/view/n_I7FbY0LaY/
  [11]: http://pan.baidu.com/s/1o8PMGFw
  [12]: http://pan.baidu.com/s/1eSgbNs2
  [13]: http://pan.baidu.com/s/1hrW4tTE
  [14]: http://www.tudou.com/programs/view/yYiVPis8bIQ/
  [15]: http://www.tudou.com/programs/view/_iOJF9sQoJw/
  [16]: http://www.tudou.com/programs/view/aej0s7LjBjM/
  [17]: http://www.tudou.com/programs/view/5nw7NtVnrjY/
  [18]: http://pan.baidu.com/s/1pLo6VhT
  [19]: http://www.tudou.com/programs/view/0wKaMJ2WcmI/
  [20]: http://pan.baidu.com/s/1gfr5bMF
  [21]: http://www.tudou.com/programs/view/B2TYPM4Q_WY/
  [22]: http://www.tudou.com/programs/view/nhrVKtfjpYY/
  [23]: http://pan.baidu.com/s/1o7J0QCi
  [24]: http://www.tudou.com/programs/view/awKED9sCaOE/
  [25]: http://pan.baidu.com/s/1jHUyx1c
  [26]: http://www.tudou.com/programs/view/BsJXQTHrHvw/?spm=a2h0k.8191414.BsJXQTHrHvw.A
  [27]: http://www.tudou.com/programs/view/7BWmOVSC200/?spm=a2h0k.8191414.7BWmOVSC200.A
  [28]: http://wenku.baidu.com/view/3509192c3169a4517723a358.html
  [29]: http://www.tudou.com/programs/view/GKyPV5hNYC4/
  [30]: http://wenku.baidu.com/view/9ce04d8c6529647d272852f7.html