
[Disqus]: http://disqus.com/
[GitHub]: https://github.com/
[Google Custom Search]: http://www.google.com/cse/
[Gravatar]: http://gravatar.com/
[jekyll]: https://github.com/mojombo/jekyl
